<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800 text-center"><?= $title; ?></h1>
    <div class="row text-center">
        <?php $no = 1; ?>
        <?php foreach ($candidate as $c) : ?>
            <div class="col mb-2">
                <!-- Icon, Title and Description Card -->
                <div class="card pmd-card text-center">
                    <div class="card-body">
                        <div class="pmd-card-icon">
                            <a href="<?= base_url() ?>voting/vote/<?= $c['id_candidate']; ?>" class="text-decoration-none">
                                <img src="<?= base_url() ?>assets/img/candidate/<?= $c['foto']; ?>" class="thumbnail rounded img-fluid" width="200" height="200">
                        </div>
                        <h4 class="card-title"><?= $c['nama_candidate']; ?></h4>
                        </a>
                    </div>
                </div>
            </div>
            <?php $no++; ?>
        <?php endforeach; ?>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->