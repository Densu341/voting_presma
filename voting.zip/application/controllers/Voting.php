<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Voting extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Candidate_model');
    }

    public function index()
    {
        $data['title'] = 'Mobile Voting';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['candidate'] = $this->Candidate_model->get_candidate();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('voting/index', $data);
        $this->load->view('templates/footer');
    }

    public function vote($id_candidate)
    {
        $data['title'] = 'Vote';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['candidate'] = $this->Candidate_model->get_candidate_by_id($id_candidate);
        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('voting/vote', $data);
        $this->load->view('templates/footer');
    }
}
